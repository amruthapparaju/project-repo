package com.springdemo;

import java.util.Scanner;
//5 program
public class MinAndMaxsub5 {
   public int max(int [] array) {
      int max = 0;
     
      for(int i=0; i<array.length; i++ ) {
         if(array[i]>max) {
            max = array[i];
         }
      }
      return max;
   }
   public int min(int [] array) {
      int min = array[0];
     
      for(int i=0; i<array.length; i++ ) {
         if(array[i]<min) {
            min = array[i];
         }
      }
      return min;
   }
   public static void main(String args[]) {
 

       
     int[]  myArray= {1,4,65,56,54,54,56};
       
      MinAndMaxsub5 m = new MinAndMaxsub5();
      
      int max = m.max(myArray);
      int min = m.min(myArray);
      System.out.println("Maximum value in the array is::"+max);
      System.out.println("Minimum value in the array is::"+min);
      
      
      int sub=max-min;
      
      System.out.println(sub);
      
      
   }
}
