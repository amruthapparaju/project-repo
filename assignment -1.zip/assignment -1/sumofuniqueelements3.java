package com.springdemo;

import java.util.HashMap;
import java.util.Iterator;
import java.util.Scanner;
import java.util.Set; 
public class sumofuniqueelements3 { 
//3 program
	public static void main(String args[]) 

	{ 
		
		
            int temp=0;
        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of the array that is to be created::");
        int size = sc.nextInt();
        int[] myArray = new int[size];
        System.out.println("Enter the elements of the array ::");
        for(int i=0; i<size; i++) {
           myArray[i] = sc.nextInt();
        }
        
     	HashMap<Integer,Integer> hm = new HashMap<Integer,Integer>(); 
		for (int i = 0; i < myArray.length; i++) { 
			hm.put(myArray[i], i); 
		} 
		System.out.println(hm.keySet());
		
		Set<Integer> keySet = hm.keySet();
		
		
  
		Iterator<Integer> iterator = keySet.iterator();
		Integer next = null;
		while(iterator.hasNext())
		{
		
			 next = iterator.next();
	temp=next+temp;
		
		} 
		System.out.println(temp);

	}
} 
