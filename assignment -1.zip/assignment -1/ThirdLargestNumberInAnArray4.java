package com.springdemo;

import java.util.Scanner;

public class ThirdLargestNumberInAnArray4 {
	//4 progrm
   public static void main(String args[]){
   int temp, size1;
   
	
   Scanner sc = new Scanner(System.in);
   System.out.println("Enter the size of the array that is to be created::");
   int size = sc.nextInt();
   int[] myArray = new int[size];
   System.out.println("Enter the elements of the array ::");
   for(int i=0; i<size; i++) {
      myArray[i] = sc.nextInt();
   }
   size1 = myArray.length;
   
   for(int i = 0; i<size1; i++ ){
      for(int j = i+1; j<size; j++){
         if(myArray[i]>myArray[j]){
            temp = myArray[i];
            myArray[i] = myArray[j];
            myArray[j] = temp;
         }
      }
   }
   System.out.println("Third largest number is:: "+myArray[size-3]);
   }
}