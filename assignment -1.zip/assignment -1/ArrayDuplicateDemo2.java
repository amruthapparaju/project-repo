package com.springdemo;

import java.util.HashMap;
import java.util.Scanner; 
public class ArrayDuplicateDemo2 { 
//2 program
	public static void main(String args[]) 

	{ 
		
		

        Scanner sc = new Scanner(System.in);
        System.out.println("Enter the size of the array that is to be created::");
        int size = sc.nextInt();
        int[] myArray = new int[size];
        System.out.println("Enter the elements of the array ::");
        for(int i=0; i<size; i++) {
           myArray[i] = sc.nextInt();
        }
        
     	HashMap<Integer,Integer> hm = new HashMap<Integer,Integer>(); 
		for (int i = 0; i < myArray.length; i++) { 
			hm.put(myArray[i], i); 
		} 
		System.out.println(hm.keySet()); 

	} 

} 
