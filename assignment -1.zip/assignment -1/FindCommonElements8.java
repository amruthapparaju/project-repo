package com.springdemo;

import java.util.ArrayList;
import java.util.Arrays;
import java.util.Iterator;

public class FindCommonElements8 {
	//8th program
	  
	public static void main(String args[]){
		   
	        //int i = 0, j = 0, k = 0; 

		   int ar1[] = {1, 5, 10, 20, 40,  80};
		int   ar2[] = {6, 7, 20, 80, 100};
		 int  ar3[] = {3, 4, 15, 20, 30, 70, 80, 120};

		 

	ArrayList<Integer> a1 = new ArrayList<Integer>();

	        

		for(int i = 0; i < ar2.length; i++ ) {
        	for(int j = 0; j < ar3.length; j++) {
        		if(ar2[i] == ar3[j]) {
        			for(int k = 0; k < ar1.length; k++) {
        				if(ar2[i] == ar1[k]) {

        				{
	        					a1.add(ar2[i]);

	        					break;
        					}
        				}
        			}

        			break;


        		}
        	}

        
		}
		System.out.println(a1);

	}

}



